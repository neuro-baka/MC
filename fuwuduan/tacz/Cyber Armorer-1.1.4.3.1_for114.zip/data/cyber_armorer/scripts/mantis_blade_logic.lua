local M = {}

function M.shoot(api)
end

return M